#include "Observer.h"

Observer::Observer()
{
}

Observer::~Observer()
{
}

void Observer::updateView()
{
}

void Observer::updateError()
{
}