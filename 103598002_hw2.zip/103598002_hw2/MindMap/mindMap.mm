0 "Computer" 2 7 
1 "windows" 5 6 
2 "OS" 1 3 4 
3 "IOS" 
4 "Linux" 
5 "DirectX" 
6 "Microsoft Office" 
7 "Network" 8 9 
8 "Wireless" 10 11 
9 "Cable" 
10 "802.11a" 
11 "802.11b" 
