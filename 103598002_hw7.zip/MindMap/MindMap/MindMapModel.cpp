#include "MindMapModel.h"
#include "EditComponentCommand.h"
#include "ChangeParentCommand.h"
#include "DeleteComponentCommand.h"
#include "InsertChildCommand.h"
#include "InsertParentCommand.h"
#include "InsertSiblingCommand.h"
#include "CutNodeCommand.h"
#include "PasteNodeCommand.h"
#include "AddDecoratorCommand.h"
#include "ClearDecoratorCommand.h"
#include "DisplayComponentVisitor.h"
#include "SaveComponentVisitor.h"
#include "SimpleExpendAndCollapseComponentVisitor.h"
#include "AllExpendAndCollapseComponentVisitor.h"
#include <regex>
#include <fstream>

MindMapModel::MindMapModel(void)
{
    _component = NULL;
    _cloneItem = NULL;
}

MindMapModel::~MindMapModel(void)
{
    clearList();
}

void MindMapModel::addRectangleDecorator()
{
    Component* decorator = _componentFactory.createComponent(RECTANGLE_TYPE);
    _commandManager.execute(new AddDecoratorCommand(_component, decorator, this));
}

void MindMapModel::addCircleDecorator()
{
    Component* decorator = _componentFactory.createComponent(CIRCLE_TYPE);
    _commandManager.execute(new AddDecoratorCommand(_component, decorator, this));
}

void MindMapModel::addTriangleDecorator()
{
    Component* decorator = _componentFactory.createComponent(TRIANGLE_TYPE);
    _commandManager.execute(new AddDecoratorCommand(_component, decorator, this));
}

void MindMapModel::clearAllDecorator()
{
    _commandManager.execute(new ClearDecoratorCommand(_component, this));
}

void MindMapModel::createMindMap(string topic)  //�s�ؤ@��Mindmap
{
    clearList();
    Component* root = _componentFactory.createComponent(ROOT_TYPE);
    _componentFactory.countId();
    root->setDescription(topic);
    _nodelist.push_back(root);
}

void MindMapModel::clearList()  //�M�Ťw�s��Mindmap
{
    _commandManager.clearAllCommand();
    delete findNodeByID(0);
    _nodelist.clear();
    _component = NULL;
    _componentFactory.setId(0);
}

void MindMapModel::insertNode(char mode)  //���JNode
{
    Component* newNode = createNode();
    if (mode == 'a')
    {
        _commandManager.execute(new InsertParentCommand(_component, newNode, this));
    }
    else if (mode == 'b')
    {
        _commandManager.execute(new InsertChildCommand(_component, newNode, this));
    }
    else if (mode == 'c')
    {
        _commandManager.execute(new InsertSiblingCommand(_component, newNode, this));
    }
}

void MindMapModel::doInsertNode(Component* child)
{
    _nodelist.push_back(child);
    _componentFactory.countId();
}

void MindMapModel::doUninsertNode(Component* child)
{
    doDeleteNode(child);
    _componentFactory.unCountId();
}

Component* MindMapModel::createNode() //�s�ؤ@��Node
{
    Component* newNode = _componentFactory.createComponent(NODE_TYPE);
    return newNode;
}

void MindMapModel::setDescription(string description)
{
    int lastID = _componentFactory.getId() - 1;
    findNodeByID(lastID)->setDescription(description);
}

Component* MindMapModel::findNodeByID(int id)  //���Component
{
    for (list<Component*>::iterator i = _nodelist.begin(); i != _nodelist.end(); i++)
    {
        if ((*i)->getId() == id)
        {
            return *i;
        }
    }
    return NULL;
}

bool MindMapModel::selectComponent(int id)  //���Component
{
    disableSelected();
    _component = findNodeByID(id);
    if (_component == NULL)
    {
        return false;
    }
    _component->setSelected(true);
    return true;
}

string MindMapModel::getMessage() //���o�B�z�T��
{
    return _message;
}

void MindMapModel::changeDescription(string newDescription)
{
    _commandManager.execute(new EditComponentCommand(newDescription, _component));
}

void MindMapModel::changeParent(int parentID)
{
    Component* parent = findNodeByID(parentID);
    _commandManager.execute(new ChangeParentCommand(_component, parent));
}

void MindMapModel::deleteComponent()
{
    _commandManager.execute(new DeleteComponentCommand(_component, this));
}

void MindMapModel::cutComponent()
{
    cloneItem();
    _commandManager.execute(new CutNodeCommand(_component, this));
}

void MindMapModel::pasteComponent()
{
    _commandManager.execute(new PasteNodeCommand(_cloneItem->clone(), this));
}

void MindMapModel::doDeleteNode(Component* component)
{
    _nodelist.remove(component);
}

void MindMapModel::doAddNodes(list<Component*> components)
{
    _nodelist = components;
    _componentFactory.setId(_nodelist.size());
}

list<Component*> MindMapModel::getNodeList()
{
    return _nodelist;
}

void MindMapModel::redo()
{
    _commandManager.redo();
}

void MindMapModel::undo()
{
    _commandManager.undo();
}

bool MindMapModel::isRoot()
{
    if (_component->getType() == ROOT_TYPE)
    {
        return true;
    }
    return false;
}

Component* MindMapModel::getSelectComponent()
{
    return _component;
}

void MindMapModel::display()  //���MindMap
{
    string content;
    stringstream outputstream(content);
    Component* root = findNodeByID(0);
    if (root == NULL)
    {
        throw ERROR_DISPLAY;
    }
    outputstream << THE_MIND_MAP << root->getDescription() << DISPLAY_MINDMAP << endl;
    root->display(outputstream, EMPTY_STRING);
    outputstream << endl;
    _message = outputstream.str();
}

void MindMapModel::saveMindMap(string filename)  //�s��MindMap
{
    SaveComponentVisitor visitor;
    if (_nodelist.size() == 0)
    {
        throw ERROR_SAVE;
    }
    Component* root = findNodeByID(0)->getDecorator();
    root->accept(&visitor);
    visitor.saveFile(filename);
    display();
    _message += SAVE_FILE_SUCCESS;
}

void MindMapModel::loadMindMap(string filename)  //Ū��
{
    vector<vector<string>> components;
    string inputString;
    fstream file;
    file.open(filename, ios::in);
    if (!file) //�p�G�}���ɮץ��� ��X�r��
    {
        throw ERROR_OPEN_FILE;
    }
    clearList();
    while (getline(file, inputString))
    {
        regex regA("( \")|(\" )");
        string wordD = "\n";
        stringstream componentString(regex_replace(inputString, regA, wordD)); // Insert the string into a stream
        string componentElement;
        vector<string> component; // Create vector to hold our words
        while (getline(componentString, componentElement, '\n'))
        {
            component.push_back(componentElement);
        }
        components.push_back(component);
    }
    createMindMapByList(components);
    createNodesConnectionByList(components);
    disableSelected();
}

void MindMapModel::createNodesConnectionByList(vector<vector<string>> components)  //�إ�Node���������Y
{
    //components: id, description, type, connection
    for (unsigned int i = 0; i < components.size(); i++)
    {
        Component* parnet = findNodeByID(i);
        int NODE_CONNECTION_LIST_LOCATION = 4;
        for (unsigned int j = NODE_CONNECTION_LIST_LOCATION; j < components[i].size(); j++)
        {
            stringstream childrenString(components[i][NODE_CONNECTION_LIST_LOCATION]);
            string child;
            while (childrenString >> child)
            {
                int childID = atoi(child.c_str());
                parnet->addChild(findNodeByID(childID));
            }
        }
    }
}

void MindMapModel::createMindMapByList(vector<vector<string>> components) //��Ū�ɫ�List�ӥ[�JNode
{
    //components: id, description, type, connection
    createMindMap(components[0][1]);
    for (unsigned int i = 1; i < components.size(); i++)
    {
        if (components[i][3] != NODE_TYPE)
        {
            Component* decorator = _componentFactory.createComponent(components[i][3]);
            _componentFactory.countId();
            _nodelist.push_back(decorator);
        }
        else
        {
            doInsertNode(createNode());
            selectComponent(i);
            setDescription(components[i][1]);
        }
    }
}

void MindMapModel::draw(MindMapSceneAdapter* scene)  //ø�XMindMap
{
    Component* root = findNodeByID(0);
    if (root == NULL)
    {
        return;
    }
    root = root->getDecorator();
    int position = 0;
    root->calculatePos(position, 0, scene, NONE_SIDE);
    DisplayComponentVisitor visitor(scene);
    root->accept(&visitor);
}

void MindMapModel::disableSelected() //�������
{
    for (auto item : _nodelist)
    {
        item->setSelected(false);
    }
}

void MindMapModel::cloneItem()  //�ƻsComponent
{
    delete _cloneItem;
    _cloneItem = _component->getDecorator()->clone();
}

void MindMapModel::doCutNodes(Component* component)  //�ŤU
{
    _nodelist.remove(component);
    for (auto item : component->getNodeList())
    {
        doCutNodes(item);
    }
}

void MindMapModel::doClearDecorator(Component* decorator, Component* component)  //�M���˹�
{
    if (decorator == component)
    {
        return;
    }
    _nodelist.remove(decorator);
    for (auto item : decorator->getNodeList())
    {
        doClearDecorator(item, component);
    }
}

void MindMapModel::doPasteNodes(Component* component) //�K�W
{
    component->setId(_componentFactory.getId());
    _nodelist.push_back(component);
    _componentFactory.countId();
    for (auto item : component->getNodeList())
    {
        doPasteNodes(item);
    }
}

bool MindMapModel::isCanRedo() //�T�{�O�_�i�HRedo
{
    if (_commandManager.getRedoCommandStack().size() != 0)
    {
        return true;
    }
    return false;
}

bool MindMapModel::isCanUndo() //�T�{�O�_�i�HUndo
{
    if (_commandManager.getUndoCommandStack().size() != 0)
    {
        return true;
    }
    return false;
}

bool MindMapModel::isHaveDecorator() //�T�{�O�_���˹�
{
    if (_component == NULL || _component == _component->getDecorator())
    {
        return false;
    }
    return true;
}

void MindMapModel::simpleExpend()
{
    SimpleExpendAndCollapseComponentVisitor visitor;
    _component->accept(&visitor);
}

void MindMapModel::allExpend()
{
    AllExpendAndCollapseComponentVisitor visitor;
    _component->accept(&visitor);
}

void MindMapModel::up()
{
    Component* component = _component->getDecorator();
    component->getParent()->up(component);
}

void MindMapModel::down()
{
    Component* component = _component->getDecorator();
    component->getParent()->down(component);
}

bool MindMapModel::isCanUp()
{
    if (_component->getType() == ROOT_TYPE)
    {
        return false;
    }
    Component* component = _component->getDecorator();
    return !component->getParent()->isUpComonent(component);
}

bool MindMapModel::isCanDown()
{
    if (_component->getType() == ROOT_TYPE)
    {
        return false;
    }
    Component* component = _component->getDecorator();
    return !component->getParent()->isUnderComonent(component);
}