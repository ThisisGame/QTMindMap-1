#include "ComponentVisitor.h"

ComponentVisitor::ComponentVisitor()
{
}

ComponentVisitor::~ComponentVisitor()
{
}
