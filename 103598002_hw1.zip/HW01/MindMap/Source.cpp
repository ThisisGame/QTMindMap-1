#include <iostream>
#include "TextUIView.h"
using namespace std;

int main()
{
    TextUIView* view = new TextUIView();
    view->run();
    system("PAUSE");
    return 0;
}