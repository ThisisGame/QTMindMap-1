#pragma once
#include "Command.h"
class 1pasteNodeCommand :
    public Command
{
    public:
        1pasteNodeCommand();
        ~1pasteNodeCommand();
};

