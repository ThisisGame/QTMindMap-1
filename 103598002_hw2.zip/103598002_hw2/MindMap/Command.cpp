#include "Command.h"

Command::Command()
{
}

Command::~Command()
{
}
