#include "MindMapSceneAdapter.h"

MindMapSceneAdapter::MindMapSceneAdapter()
{
}

MindMapSceneAdapter::~MindMapSceneAdapter()
{
}
